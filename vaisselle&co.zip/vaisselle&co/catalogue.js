// Fonction pour afficher un onglet spécifique
function showTab(tabName) {
    // 1. Cacher tous les contenus d'onglets
    const allTabContents = document.querySelectorAll('.tab-contenu');
    allTabContents.forEach(content => {
        content.classList.remove('active');
    });
    
    // 2. Désactiver tous les boutons d'onglets
    const allTabButtons = document.querySelectorAll('.tab-bouton');
    allTabButtons.forEach(button => {
        button.classList.remove('active');
    });
    
    // 3. Afficher le contenu de l'onglet sélectionné
    const selectedTab = document.getElementById(tabName);
    if (selectedTab) {
        selectedTab.classList.add('active');
    }
    
    // 4. Activer le bouton correspondant
    const clickedButton = event.currentTarget;
    if (clickedButton) {
        clickedButton.classList.add('active');
    }
    
    // 5. Faire défiler doucement vers le contenu (optionnel)
    selectedTab.scrollIntoView({ 
        behavior: 'smooth', 
        block: 'nearest' 
    });
}

// Initialisation au chargement de la page
document.addEventListener('DOMContentLoaded', function() {
    const firstTab = document.getElementById('assiettes');
    const firstButton = document.querySelector('.tab-bouton');
    
    if (firstTab) {
        firstTab.classList.add('active');
    }
    
    if (firstButton) {
        firstButton.classList.add('active');
    }
});