let compteur = localStorage.getItem('visites');

// 2️⃣ Si aucune valeur n'existe encore, on commence à 0
if (compteur === null) {
    compteur = 0;
}

// 3️⃣ On ajoute +1 à chaque visite
compteur++;

// 4️⃣ On sauvegarde la nouvelle valeur
localStorage.setItem('visites', compteur);

// 5️⃣ On affiche le nombre dans la page
document.getElementById('compteur-visites-valeur').textContent = compteur;