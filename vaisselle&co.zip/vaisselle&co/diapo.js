let numeroDiapo = 1;  // Photo actuellement affichée
let minuteurDiapo;    // Timer pour le défilement automatique

// Démarrer le diaporama quand la page est chargée
document.addEventListener('DOMContentLoaded', function() {
    // Vérifier que le diaporama existe sur la page
    if (document.querySelector('.boite-diaporama')) {
        afficherDiapos(numeroDiapo);  // Afficher la première photo
        demarrerDefilementAuto();     // Démarrer le défilement automatique
    }
});

// FONCTION PRINCIPALE : Afficher une photo spécifique
function afficherDiapos(numero) {
    // Récupérer toutes les photos
    const diapositives = document.getElementsByClassName('diapo');
    // Récupérer tous les points de navigation
    const points = document.getElementsByClassName('point');
    
    // Si aucune photo n'existe, arrêter
    if (diapositives.length === 0) return;
    
    // Si on dépasse le nombre de photos, revenir à la première
    if (numero > diapositives.length) {
        numeroDiapo = 1;
    }
    
    // Si on va en arrière de la première photo, aller à la dernière
    if (numero < 1) {
        numeroDiapo = diapositives.length;
    }
    
    // CACHER TOUTES LES PHOTOS
    for (let i = 0; i < diapositives.length; i++) {
        diapositives[i].classList.remove('affiche');
        diapositives[i].style.display = 'none';
    }
    
    // DÉSACTIVER TOUS LES POINTS
    for (let i = 0; i < points.length; i++) {
        points[i].classList.remove('actif');
    }
    
    // AFFICHER LA PHOTO SÉLECTIONNÉE
    if (diapositives[numeroDiapo - 1]) {
        diapositives[numeroDiapo - 1].style.display = 'block';
        diapositives[numeroDiapo - 1].classList.add('affiche');
    }
    
    // ACTIVER LE POINT CORRESPONDANT
    if (points[numeroDiapo - 1]) {
        points[numeroDiapo - 1].classList.add('actif');
    }
}

// FONCTION : Changer de photo avec les flèches
function changerDiapo(direction) {
    clearInterval(minuteurDiapo);  // Arrêter le défilement auto
    numeroDiapo += direction;       // Ajouter ou retirer 1
    afficherDiapos(numeroDiapo);   // Afficher la nouvelle photo
    demarrerDefilementAuto();      // Redémarrer le défilement auto
}


// FONCTION : Défilement automatique des photos
function demarrerDefilementAuto() {
    minuteurDiapo = setInterval(function() {
        numeroDiapo++;              // Passer à la photo suivante
        afficherDiapos(numeroDiapo); // Afficher la photo
    }, 5000); // Changer toutes les 5 secondes (5000 millisecondes)
}

// ARRÊTER le défilement quand la souris passe dessus
document.addEventListener('DOMContentLoaded', function() {
    const boiteDiapo = document.querySelector('.boite-diaporama');
    
    if (boiteDiapo) {
        // Quand la souris entre dans le diaporama
        boiteDiapo.addEventListener('mouseenter', function() {
            clearInterval(minuteurDiapo);
        });
        
        // Quand la souris sort du diaporama
        boiteDiapo.addEventListener('mouseleave', function() {
            demarrerDefilementAuto();
        });
    }
});

// SUPPORT TACTILE pour téléphone (glisser avec le doigt)
let debutToucher = 0;  // Position de départ du doigt
let finToucher = 0;    // Position finale du doigt

document.addEventListener('DOMContentLoaded', function() {
    const boiteDiapo = document.querySelector('.boite-diaporama');
    
    if (boiteDiapo) {
        // Quand on pose le doigt
        boiteDiapo.addEventListener('touchstart', function(e) {
            debutToucher = e.changedTouches[0].screenX;
        });
        
        // Quand on lève le doigt
        boiteDiapo.addEventListener('touchend', function(e) {
            finToucher = e.changedTouches[0].screenX;
            gererGlissement();
        });
    }
});

// FONCTION : Détecter le sens du glissement
function gererGlissement() {
    // Glissement vers la gauche (photo suivante)
    if (finToucher < debutToucher - 50) {
        changerDiapo(1);
    }
    // Glissement vers la droite (photo précédente)
    if (finToucher > debutToucher + 50) {
        changerDiapo(-1);
    }
}